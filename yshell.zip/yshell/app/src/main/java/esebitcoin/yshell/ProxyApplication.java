package esebitcoin.yshell;

import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.util.ArrayMap;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import dalvik.system.DexClassLoader;

public class ProxyApplication extends Application {
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        File cache = getDir("eshell",MODE_PRIVATE);
        String sDex = cache +"/encrypt.dex";

        File dexFile = FileManager.releaseAssetsFile(this,"encrypt.dex",sDex,null);

        ClassLoader cl = new DexClassLoader(sDex,getDir("eshell_aot",MODE_PRIVATE).getAbsolutePath(), getApplicationInfo().nativeLibraryDir,getClassLoader());
        Object currentActivityThread = RefInvoke.invokeStaticMethod("android.app.ActivityThread", "currentActivityThread",new Class[]{},new Object[]{});
        ArrayMap mPackages = (ArrayMap) RefInvoke.getFieldOjbect("android.app.ActivityThread", "mPackages",currentActivityThread);
        WeakReference wr = (WeakReference) mPackages.get(getPackageName());
        RefInvoke.setFieldOjbect("android.app.LoadedApk","mClassLoader",wr.get(),cl);

        return;
    }
    @Override
    public void onCreate() {
        super.onCreate();

        Object currentActivityThread = RefInvoke.invokeStaticMethod("android.app.ActivityThread", "currentActivityThread",new Class[]{},new Object[]{});
        Object mBoundApplication = RefInvoke.getFieldOjbect("android.app.ActivityThread", "mBoundApplication",currentActivityThread);
        Object loadedApkInfo = RefInvoke.getFieldOjbect("android.app.ActivityThread$AppBindData", "info",mBoundApplication);

        RefInvoke.setFieldOjbect("android.app.LoadedApk","mApplication",loadedApkInfo,null);

        String srcAppName = "esebitcoin.yshell.MyApplication";

        ApplicationInfo appInfo_LoadedApke = (ApplicationInfo) RefInvoke.getFieldOjbect("android.app.LoadedApk", "mApplicationInfo",loadedApkInfo);
        appInfo_LoadedApke.className = srcAppName;

        ApplicationInfo appinfo_In_AppBindData = (ApplicationInfo) RefInvoke.getFieldOjbect("android.app.ActivityThread$AppBindData", "appInfo",mBoundApplication);
        appinfo_In_AppBindData.className = srcAppName;

        Application oldApplication = (Application) RefInvoke.getFieldOjbect("android.app.ActivityThread", "mInitialApplication",currentActivityThread);


        ArrayList<Application> mAllApplications = (ArrayList<Application>) RefInvoke.getFieldOjbect("android.app.ActivityThread", "mAllApplications",currentActivityThread);

        mAllApplications.remove(oldApplication);

        Application realApp = (Application) RefInvoke.invokeMethod("android.app.LoadedApk", "makeApplication",new Class[]{boolean.class,Instrumentation.class}, loadedApkInfo,new Object[]{false,null});

        realApp.onCreate();

        RefInvoke.setFieldOjbect("android.app.ActivityThread","mInitialApplication", currentActivityThread,realApp);

        return;
    }

}
